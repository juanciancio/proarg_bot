export class BetModel {
  id: number = -1;
  telegramId: number = 0;
  date: string = '';
}
