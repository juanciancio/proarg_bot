export class UserModel {
  id: number = -1;
  name: string = '';
  birthdate: string = '';
  telegramAlias: string = '';
  telegramId: number = 0;
  state: string = '';
}
